/*
 *Developer: Kyle Hake
 *Class: CS-360
 *Description:  This is used to check if the user will give SMS permissions for notifications to the
 * application for upcoming events.
 */

package com.example.cs360project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.view.View;
import android.widget.Button;

import android.os.Bundle;
import android.widget.Toast;

public class Permissions extends AppCompatActivity {

    private Button allow;

    private static final int ALLOW_SMS_PERMISSION_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_permissions);

        allow = findViewById(R.id.allowSMSText);

        // Set Buttons on Click Listeners
        allow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                checkPermission(Manifest.permission.SEND_SMS, ALLOW_SMS_PERMISSION_CODE);
                Intent intent = new Intent(getApplicationContext(), EventTracker.class);
                startActivity(intent);
            }
        });
    }

    // Function to check and request permission.
    public void checkPermission(String permission, int requestCode)
    {
        if (ContextCompat.checkSelfPermission(Permissions.this, permission) == PackageManager.PERMISSION_DENIED) {

            // Requesting the permission
            ActivityCompat.requestPermissions(Permissions.this, new String[] { permission }, requestCode);
        }
        else {
            Toast.makeText(Permissions.this, "Permission already granted", Toast.LENGTH_SHORT).show();
        }
    }

    public void navigateEventTracker (View view) {
        Intent intent = new Intent(this, EventTracker.class);
        startActivity(intent);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode,
                permissions,
                grantResults);

        if (requestCode == ALLOW_SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(Permissions.this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(Permissions.this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}