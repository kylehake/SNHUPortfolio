/*
 *Developer: Kyle Hake
 *Class: CS-360
 *Description:  This is the log-in page of the app, the user can input username/password or create an account.
 */

package com.example.cs360project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //Initialization of Variables
    private final AppCompatActivity activity = MainActivity.this;

    private EditText editLoginUsername;
    private EditText editLoginPassword;
    private TextView loginUsername;
    private TextView loginPassword;

    private Button login;
    private Button createAccount;

    private UsernameDatabaseHelper usernameDatabaseHelper;
    private InputValidation inputValidation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //View Initialization
        login = findViewById(R.id.loginButton);
        createAccount = findViewById(R.id.createAccountButton);

        editLoginUsername = findViewById(R.id.editTextUsername);
        editLoginPassword = findViewById(R.id.editTextPassword);
        loginUsername = findViewById(R.id.usernameText);
        loginPassword = findViewById(R.id.passwordText);

        //Object Initialization
        usernameDatabaseHelper = new UsernameDatabaseHelper(activity);
        inputValidation = new InputValidation(activity);

        //onClick for checking login and navigating to the home screen
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validateLogin(v);
            }
        });


        //onClick for creating an account
        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createAccount(v);
            }
        });


    }

    private void validateLogin (View view) {
        if (!inputValidation.isInputEditTextFilled(editLoginUsername, loginUsername, getString(R.string.error_message_username))) {
            return;
        }
        if (!inputValidation.isInputEditTextFilled(editLoginPassword, loginPassword, getString(R.string.error_message_password))) {
            return;
        }

        if (usernameDatabaseHelper.checkUser((editLoginUsername.getText().toString().trim()),(editLoginPassword.getText().toString().trim()))) {

            // Toast to show success message that record saved successfully
            Toast.makeText(MainActivity.this, "Log-in Successful.", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, EventTracker.class);
            startActivity(intent);

        } else {
            // Toast to show error message that record already exists
            Toast.makeText(MainActivity.this, "Username / Password does not match.", Toast.LENGTH_SHORT).show();
        }
    }

    // intent used to navigate to the create account page
    public void createAccount (View view) {
        Intent intent = new Intent(this, CreateAccount.class);
        startActivity(intent);

    }
}