/*
 *Developer: Kyle Hake
 *Class: CS-360
 *Description:  This is used to add an event to the database.
 */

package com.example.cs360project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.content.Intent;
import android.widget.Toast;

public class EditEvent extends AppCompatActivity {

    // Initialization of variables
    private final AppCompatActivity activity = EditEvent.this;

    private TextView eventNameText;
    private TextView eventDateText;
    private TextView eventLocationText;
    private TextView eventDetailsText;

    private EditText updateEventName;
    private EditText updateEventDate;
    private EditText updateEventLocation;
    private EditText updateEventDetails;

    private Button updateEventButton;

    private Event event;
    private EventDatabaseHelper eventDatabaseHelper;
    private InputValidation inputValidation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_edit_event);

        // Views Initialization
        eventNameText = findViewById(R.id.newEventText);
        eventDateText = findViewById(R.id.dateText);
        eventLocationText = findViewById(R.id.locationText);
        eventDetailsText = findViewById(R.id.detailsText);

        updateEventName = findViewById(R.id.updateEventName);
        updateEventDate = findViewById(R.id.updateDate);
        updateEventLocation = findViewById(R.id.updateLocation);
        updateEventDetails = findViewById(R.id.updateEventDetails);

        updateEventButton = findViewById(R.id.updateEventButton);

        // Objects Initialization
        eventDatabaseHelper = new EventDatabaseHelper(activity);
        inputValidation = new InputValidation(activity);
        event = new Event();

        // Pulls the putExtras from the Adaptor to know which to update and previous values
        Intent intentForBundle = getIntent();
        Bundle bundle = intentForBundle.getExtras();

        if (bundle != null) {
            int id = bundle.getInt("event-id");
            event.setId(id);
            String name = bundle.getString("event-name");
            updateEventName.setText(name);
            String date = bundle.getString("event-date");
            updateEventDate.setText(date);
            String location = bundle.getString("event-location");
            updateEventLocation.setText(location);
            String details = bundle.getString("event-details");
            updateEventDetails.setText(details);
        }

        // onClickListener Initialization
        updateEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateEventDatabase();
            }
        });
    }

        /*This function checks for input validation for each event variable, then updates
         * the event to the database.  Toasts a confirmation message and directs back to home screen after
         */
        private void updateEventDatabase () {
            if (!inputValidation.isInputEditTextFilled(updateEventName, eventNameText, getString(R.string.error_message_eventname))) {
                return;
            }
            if (!inputValidation.isInputEditTextFilled(updateEventDate, eventDateText, getString(R.string.error_message_eventdate))) {
                return;
            }
            if (!inputValidation.isInputEditTextFilled(updateEventLocation, eventLocationText, getString(R.string.error_message_eventlocation))) {
                return;
            }
            if (!inputValidation.isInputEditTextFilled(updateEventDetails, eventDetailsText, getString(R.string.error_message_eventdetails))) {
                return;
            }

            // Creates the event to replace the old contents
            event.setEventName(updateEventName.getText().toString().trim());
            event.setEventDate(updateEventDate.getText().toString().trim());
            event.setEventLocation(updateEventLocation.getText().toString().trim());
            event.setEventDetails(updateEventDetails.getText().toString().trim());

            eventDatabaseHelper.updateEvent(event);

            // Navigates back to the home screen after the update
            Intent intent = new Intent(this, EventTracker.class);
            startActivity(intent);

            // Toast to show success message that record saved successfully
            Toast.makeText(EditEvent.this, "Event updated successfully", Toast.LENGTH_SHORT).show();

        }
    }
