/*
 *Developer: Kyle Hake
 *Class: CS-360
 *Description:  This is the event class.
 */


package com.example.cs360project;

public class Event {

    // Variables
    private int id;
    private String eventName;
    private String eventDate;
    private String eventLocation;
    private String eventDetails;

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String name) {
        this.eventName = name;
    }

    public String getEventDate() { return eventDate; }

    public void setEventDate(String date) { this.eventDate = date; }

    public String getEventLocation() {
        return eventLocation;
    }

    public void setEventLocation(String location) {
        this.eventLocation = location;
    }

    public String getEventDetails() {
        return eventDetails;
    }

    public void setEventDetails(String details) {
        this.eventDetails = details;
    }

}
