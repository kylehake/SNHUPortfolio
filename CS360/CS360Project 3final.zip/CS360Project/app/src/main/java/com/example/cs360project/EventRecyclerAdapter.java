/*
 *Developer: Kyle Hake
 *Class: CS-360
 *Description:  This is recycler adaptor used in the recycler view in the events listing on the home
 * page of the application.  It gives each event a cardView of the name and date as well as options
 * to delete and edit each event.  The goal was initially to use a swipe feature for the edit/delete
 * but was too ambitious for time constraints.
 */
package com.example.cs360project;

import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.widget.TextView;
import android.view.View;
import java.util.List;
import android.view.ViewGroup;
import android.view.LayoutInflater;
import android.util.Log;
import android.widget.Button;

public class EventRecyclerAdapter extends RecyclerView.Adapter<EventRecyclerAdapter.EventViewHolder> {

    // Variable initialization
    private Context context;
    private List<Event> listEvents;
    private EventDatabaseHelper eventDatabaseHelper;

    //Constructor with context to pull in the passed argument for eventDatabaseHelper
    public EventRecyclerAdapter(List<Event> listEvents, Context context) {
        this.listEvents = listEvents;
        this.context = context;
    }

    @Override
    public EventViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // inflating recycler item view
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_user_recycler, parent, false);

        return new EventViewHolder(itemView);
    }

    //View of each card for each event
    @Override
    public void onBindViewHolder(EventViewHolder holder, int position) {
        eventDatabaseHelper = new EventDatabaseHelper(context);
        holder.textViewName.setText(listEvents.get(position).getEventName());
        holder.textViewDate.setText(listEvents.get(position).getEventDate());

        //onClickListener to delete an event from the database
        holder.deleteEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eventDatabaseHelper.deleteEvent(listEvents.get(position));

                //updates database view after deletion
                notifyItemRemoved(position);
            }
        });

        //onClickListener to edit an event in the database
        holder.editEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, EditEvent.class);

                //Pulls the event variables from the selected event into the edit event page
                intent.putExtra("event-id", listEvents.get(position).getId());
                intent.putExtra("event-name", listEvents.get(position).getEventName());
                intent.putExtra("event-date", listEvents.get(position).getEventDate());
                intent.putExtra("event-location", listEvents.get(position).getEventLocation());
                intent.putExtra("event-details", listEvents.get(position).getEventDetails());
                context.startActivity(intent);


            }
        });


    }

    @Override
    public int getItemCount() {
        // editor view of the recyclerView
        Log.v(EventRecyclerAdapter.class.getSimpleName(),""+listEvents.size());
        return listEvents.size();
    }
    /**
     * ViewHolder class
     */
    public class EventViewHolder extends RecyclerView.ViewHolder {

        //initialization of card variables
        public TextView textViewName;
        public TextView textViewDate;
        public Button editEvent;
        public Button deleteEvent;

        public EventViewHolder(View view) {
            super(view);

            // initialization of each view on each card
            textViewName = view.findViewById(R.id.textViewName);
            textViewDate = view.findViewById(R.id.textViewDate);
            editEvent = view.findViewById(R.id.editButton);
            deleteEvent = view.findViewById(R.id.deleteButton);

            };
        }

    }

