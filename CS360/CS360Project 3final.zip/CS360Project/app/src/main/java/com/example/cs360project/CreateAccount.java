/*
 *Developer: Kyle Hake
 *Class: CS-360
 *Description:  This is used to create a user account for access to app.
 */

package com.example.cs360project;

import androidx.appcompat.app.AppCompatActivity;

import androidx.annotation.NonNull;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class CreateAccount extends AppCompatActivity {

    // Initialization of variables
    private final AppCompatActivity activity = CreateAccount.this;

    private TextView textUsername;
    private TextView textPassword;
    private TextView textRetypePassword;

    private EditText editUsername;
    private EditText editPassword;
    private EditText editReTypePassword;

    private Button createAccount;

    private InputValidation inputValidation;
    private UsernameDatabaseHelper usernameDatabaseHelper;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        // Views initialization
        textUsername = findViewById(R.id.usernameTextAccountCreate);
        textPassword = findViewById(R.id.passwordTextAccountCreate);
        textRetypePassword = findViewById(R.id.retypePasswordText);

        editUsername = findViewById(R.id.editTextUsernameAccountCreate);
        editPassword = findViewById(R.id.editTextPasswordAccountCreate);
        editReTypePassword = findViewById(R.id.editTextRetypePassword);

        createAccount = findViewById(R.id.createNewAccountButton);

        /*object initialization*/
        user = new User();
        inputValidation = new InputValidation(activity);
        usernameDatabaseHelper = new UsernameDatabaseHelper(activity);

        // onClickListener initialization
        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                postToDatabase();
                askPermissions(v);
            }
        });



    }

    /*This function checks for input validation for each account variable, then creates and adds
     * the account to the database.  Toasts a confirmation message and directs to SMS permissions after
     */
    private void postToDatabase () {

        // Input Validation
        if (!inputValidation.isInputEditTextFilled(editUsername, textUsername, getString(R.string.error_message_username))) {
            return;
        }
        if (!inputValidation.isInputEditTextFilled(editPassword, textPassword, getString(R.string.error_message_password))) {
            return;
        }

        // Checks the two password fields match
        if (!inputValidation.isInputEditTextMatches(editPassword, editReTypePassword,
                textRetypePassword, getString(R.string.error_password_match))) {
            return;
        }

        // Checks to see if the user exists already, adds if not, error messages if it does
        if (!usernameDatabaseHelper.checkUser(editUsername.getText().toString().trim())) {

            user.setName(editUsername.getText().toString().trim());
            user.setPassword(editPassword.getText().toString().trim());

            usernameDatabaseHelper.addUser(user);

            // Toast to show success message that record saved successfully
            Toast.makeText(CreateAccount.this, "Account created successfully", Toast.LENGTH_SHORT).show();

        } else {
            // Toast to show error message that record already exists
            Toast.makeText(CreateAccount.this, "This account already exists.", Toast.LENGTH_SHORT).show();
        }

    }

    public void askPermissions (View view) {
        Intent intent = new Intent(this, Permissions.class);
        startActivity(intent);

    }
}