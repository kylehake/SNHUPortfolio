/*
 *Developer: Kyle Hake
 *Class: CS-360
 *Description:  This is the class used as a database helper class to create, read, update, and delete
 * events in the application.
 */
package com.example.cs360project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;

public class EventDatabaseHelper extends SQLiteOpenHelper {

    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "Events.db";

    // User table name
    private static final String TABLE_EVENT = "event";

    // User Table Columns names
    private static final String COLUMN_EVENT_ID = "event_id";
    private static final String COLUMN_EVENT_NAME = "event_name";
    private static final String COLUMN_EVENT_DATE = "event_date";
    private static final String COLUMN_EVENT_LOCATION = "event_location";
    private static final String COLUMN_EVENT_DETAILS = "event_details";

    // create table sql query
    private String CREATE_EVENT_TABLE = "CREATE TABLE " + TABLE_EVENT + "("
            + COLUMN_EVENT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + COLUMN_EVENT_NAME + " TEXT,"
            + COLUMN_EVENT_DATE + " DATE," + COLUMN_EVENT_LOCATION + " TEXT," +
            COLUMN_EVENT_DETAILS + " TEXT" + ")";

    // drop table sql query
    private String DROP_EVENT_TABLE = "DROP TABLE IF EXISTS " + TABLE_EVENT;

    /**
     * Constructor
     *
     * @param context
     */
    public EventDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_EVENT_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        //Drop User Table if exist
        db.execSQL(DROP_EVENT_TABLE);

        // Create tables again
        onCreate(db);

    }

    /**
     * This method is to create user record
     *
     * @param event
     */
    public void addEvent(Event event) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_NAME, event.getEventName());
        values.put(COLUMN_EVENT_DATE, event.getEventDate());
        values.put(COLUMN_EVENT_LOCATION, event.getEventLocation());
        values.put(COLUMN_EVENT_DETAILS, event.getEventDetails());


        // Inserting Row
        db.insert(TABLE_EVENT, null, values);
        db.close();
    }

    /**
     * This method is to fetch all user and return the list of user records
     *
     * @return list
     */
    public List<Event> getAllEvents() {
        // array of columns to fetch
        String[] columns = {
                COLUMN_EVENT_ID,
                COLUMN_EVENT_NAME,
                COLUMN_EVENT_DATE,
                COLUMN_EVENT_LOCATION,
                COLUMN_EVENT_DETAILS
        };
        // sorting orders
        String sortOrder =
                COLUMN_EVENT_ID + " ASC";
        List<Event> eventList = new ArrayList<Event>();

        SQLiteDatabase db = this.getReadableDatabase();

        // query the user table
        /**
         * Here query function is used to fetch records from user table this function works like we use sql query.
         * SQL query equivalent to this query function is
         * SELECT user_id,user_name,user_email,user_password FROM user ORDER BY user_name;
         */
        Cursor cursor = db.query(TABLE_EVENT, //Table to query
                columns,    //columns to return
                null,        //columns for the WHERE clause
                null,        //The values for the WHERE clause
                null,       //group the rows
                null,       //filter by row groups
                sortOrder); //The sort order


        // Traversing through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Event event = new Event();
                event.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_ID))));
                event.setEventName(cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_NAME)));
                event.setEventDate(cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_DATE)));
                event.setEventLocation(cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_LOCATION)));
                event.setEventDetails(cursor.getString(cursor.getColumnIndex(COLUMN_EVENT_DETAILS)));
                // Adding user record to list
                eventList.add(event);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();

        // return user list
        return eventList;
    }

    /**
     * This method is to delete user record
     *
     * @param event
     */
    public void deleteEvent(Event event) {
        SQLiteDatabase db = this.getWritableDatabase();
        // delete user record by id
        db.delete(TABLE_EVENT, COLUMN_EVENT_ID + " = ?",
                new String[]{String.valueOf(event.getId())});
        db.close();
    }

    /**
     * This method to update user record
     *
     * @param event
     */
    public void updateEvent(Event event) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_EVENT_NAME, event.getEventName());
        values.put(COLUMN_EVENT_DATE, event.getEventDate());
        values.put(COLUMN_EVENT_LOCATION, event.getEventLocation());
        values.put(COLUMN_EVENT_DETAILS, event.getEventDetails());

        // updating row
        db.update(TABLE_EVENT, values, COLUMN_EVENT_ID + " = ?",
                new String[]{String.valueOf(event.getId())});
        db.close();
    }

}
