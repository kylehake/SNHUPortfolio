/*
 *Developer: Kyle Hake
 *Class: CS-360
 *Description:  This is used to add an event to the database.
 */


package com.example.cs360project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class AddEvent extends AppCompatActivity {

    // Initialization of variables used
    private final AppCompatActivity activity = AddEvent.this;

    private TextView eventNameText;
    private TextView eventDateText;
    private TextView eventLocationText;
    private TextView eventDetailsText;

    private EditText editEventName;
    private EditText editEventDate;
    private EditText editEventLocation;
    private EditText editEventDetails;

    private Button addEventButton;

    private Event event;
    private EventDatabaseHelper eventDatabaseHelper;
    private InputValidation inputValidation;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        // Initialization of Views
        eventNameText = findViewById(R.id.newEventText);
        eventDateText = findViewById(R.id.dateText);
        eventLocationText = findViewById(R.id.locationText);
        eventDetailsText = findViewById(R.id.detailsText);

        editEventName = findViewById(R.id.editNewEventName);
        editEventDate = findViewById(R.id.editNewEventDate);
        editEventLocation = findViewById(R.id.editNewEventLocation);
        editEventDetails = findViewById(R.id.editNewEventDetails);

        addEventButton = findViewById(R.id.addNewEventButton);

        // Initialization of Objects
        event = new Event();
        eventDatabaseHelper = new EventDatabaseHelper(activity);
        inputValidation = new InputValidation(activity);

        // Initialization of onClickListeners
        addEventButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                postToEventDatabase();
            }
        });
    }

    /*This function checks for input validation for each event variable, then creates and adds
    * the event to the database.  Toasts a confirmation message and directs back to home screen after
    */
    private void postToEventDatabase () {

        // Input Validation
        if (!inputValidation.isInputEditTextFilled(editEventName, eventNameText, getString(R.string.error_message_eventname))) {
            return;
        }
        if (!inputValidation.isInputEditTextFilled(editEventDate, eventDateText, getString(R.string.error_message_eventdate))) {
            return;
        }
        if (!inputValidation.isInputEditTextFilled(editEventLocation, eventLocationText, getString(R.string.error_message_eventlocation))) {
            return;
        }
        if (!inputValidation.isInputEditTextFilled(editEventDetails, eventDetailsText, getString(R.string.error_message_eventdetails))) {
            return;
        }

        // Creates event and adds to database using database helper function
        event.setEventName(editEventName.getText().toString().trim());
        event.setEventDate(editEventDate.getText().toString().trim());
        event.setEventLocation(editEventLocation.getText().toString().trim());
        event.setEventDetails(editEventDetails.getText().toString().trim());

        eventDatabaseHelper.addEvent(event);

        // starts the event tracker class
        Intent intent = new Intent(this, EventTracker.class);
        startActivity(intent);

        // Toast to show success message that record saved successfully
        Toast.makeText(AddEvent.this, "Event created successfully", Toast.LENGTH_SHORT).show();

    }


}