/*
 *Developer: Kyle Hake
 *Class: CS-360
 *Description:  This script is used in the home screen of the application.  Holds the add event button
 * as well as the recycler of events from the database.
 */

package com.example.cs360project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

public class EventTracker extends AppCompatActivity {

    //Initialization of variables
    private AppCompatActivity activity = EventTracker.this;
    private RecyclerView recyclerViewEvents;
    private List<Event> eventList;
    private EventRecyclerAdapter eventRecyclerAdapter;
    private EventDatabaseHelper eventDatabaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events_list);
        getSupportActionBar().setTitle("");

        //View Initialization
        recyclerViewEvents = findViewById(R.id.recyclerViewEvents);

        //Object Initialization
        eventList = new ArrayList<>();
        eventRecyclerAdapter = new EventRecyclerAdapter(eventList, this);
        eventDatabaseHelper = new EventDatabaseHelper(activity);


        //RecyclerView Initialization
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerViewEvents.setLayoutManager(mLayoutManager);
        recyclerViewEvents.setItemAnimator(new DefaultItemAnimator());
        recyclerViewEvents.setHasFixedSize(true);
        recyclerViewEvents.setAdapter(eventRecyclerAdapter);

        getDataFromSQLite();
    }


    /**
     * This method is to fetch all user records from SQLite
     */
    private void getDataFromSQLite() {

        new AsyncTask<Void, Void, Void>() {
            @Override
            protected Void doInBackground(Void... params) {
                eventList.clear();
                eventList.addAll(eventDatabaseHelper.getAllEvents());

                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                eventRecyclerAdapter.notifyDataSetChanged();
            }
        }.execute();
    }



    //Used to navigate to the add event screen
    public void addEvent (View view) {
        Intent intent = new Intent(this, AddEvent.class);
        startActivity(intent);

    }
}