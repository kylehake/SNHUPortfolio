/*
 *Developer: Kyle Hake
 *Class: CS-360
 *Description:  This is used to validate the input for blank fields before it goes into the database.
 */

package com.example.cs360project;

import android.content.Context;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class InputValidation {
        private Context context;

        /**
         * constructor
         *
         * @param context
         */
        public InputValidation(Context context) {
            this.context = context;
        }

        /**
         * method to check InputEditText filled .
         *
         * @param textInputEditText
         * @param textInputLayout
         * @param message
         * @return
         */
        public boolean isInputEditTextFilled(EditText textInputEditText, TextView textInputLayout, String message) {
            String value = textInputEditText.getText().toString().trim();
            if (value.isEmpty()) {
                Toast.makeText(context.getApplicationContext(), message, Toast.LENGTH_SHORT).show();
                return false;
            } else {
                return true;
            }
        }


      /**
        * method to check InputEditText1 and 2 match each other
        *
        * @param textInputEditText1
        * @param textInputEditText2
        * @param textInputLayout
        * @param message
        * @return
        */
        public boolean isInputEditTextMatches(EditText textInputEditText1, EditText textInputEditText2, TextView textInputLayout, String message) {
            String value1 = textInputEditText1.getText().toString().trim();
            String value2 = textInputEditText2.getText().toString().trim();
            if (!value1.contentEquals(value2)) {
                Toast.makeText(context.getApplicationContext(), message, Toast.LENGTH_SHORT).show();
                return false;
            } else {
                return true;
            }
        }
}


